package com.capgemini.store.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.store.beans.Cart;
import com.capgemini.store.beans.Category;
import com.capgemini.store.beans.Customer;

@Controller
public class URIControllers {
	@RequestMapping(value="/")
	public String getIndexPage() {
		return "cart";
	}
	
	@RequestMapping(value="/signUpPage")
	public String getsignUpPage() {
		return "signUpPage";
	}		
//	
//	@RequestMapping("/successRegistration")
//	public String getsignPage() {
//		return "now1";
//	}
	@RequestMapping(value="/signin")
	public String getsignInPage() {
		return "signin1";
	}
	
	@RequestMapping(value="/logout")
	public String logoutPage() {
		return "now1";
	}
	
//	@RequestMapping(value="/category")
//	public String categoryPage() {
//		return "categoryProducts";
//	}
	
	@RequestMapping(value="/mainDynamic")
	public String productPage() {
		return "particularProduct";
	}
	
	@ModelAttribute("customer")
	public Customer getCustomer() {
		return new Customer();
	}
	
//	@ModelAttribute("cart")
//	public Cart getCart() {
//		return new Cart();
//	}
	
	
//	@ModelAttribute("category")
//	public Category getCategory() {
//		return new Category();
//	}
}
